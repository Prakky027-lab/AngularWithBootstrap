import { Component, OnInit } from "@angular/core";
import { EmployeeService } from './app.employeeservice';
@Component({
    selector:'show-emp',
    templateUrl:'showemployee.html'
})
export class ShowEmployeeComponent implements OnInit{

    emId:number;
    emName:string;
    emSal:number;
    emDep:string;
    x:number;
    constructor(private myservice:EmployeeService){}
    empAll:any[]=[];

    ngOnInit(){
       this.empAll=this.myservice.getAllEmployee();
    }

    delete(data:number):any{
        this.empAll.splice(data,1); //To delete the data
    }

    update(data:number):any{
        this.x=data;
        this.emId=this.empAll[data].empId;
        this.emName=this.empAll[data].empName;
        this.emSal=this.empAll[data].empSal;
        this.emDep=this.empAll[data].empDep;
    }


    updateValue():any{
        this.empAll.splice(this.x,1,{empId:this.emId,empName:this.emName,empSal:this.emSal,empDep:this.emDep});
}

}